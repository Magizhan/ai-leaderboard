// ============================================================
// CONFIG
// ============================================================
const API_BASE = 'https://leaderboard.magizhan.work';
const ALARM_NAME = 'claude_usage_sync';

// ============================================================
// DOM refs
// ============================================================
const statusEl       = document.getElementById('status');
const syncBtn        = document.getElementById('syncBtn');
const navBtn         = document.getElementById('navBtn');
const preview        = document.getElementById('dataPreview');
const userEl         = document.getElementById('userName');
const sessEl         = document.getElementById('sessionPct');
const weekEl         = document.getElementById('weeklyPct');
const dashLink       = document.getElementById('dashLink');
const teamSelect     = document.getElementById('teamSelect');
const scheduleToggle = document.getElementById('scheduleToggle');
const scheduleRow    = document.getElementById('scheduleRow');
const scheduleLabel  = document.getElementById('scheduleLabel');
const freqSelect     = document.getElementById('freqSelect');

dashLink.href = API_BASE;
dashLink.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: API_BASE });
});

let scrapedData = null;

// ============================================================
// Restore saved preferences
// ============================================================
chrome.storage.local.get(
  ['claude_lb_team', 'schedule_enabled', 'schedule_interval', 'last_sync_time', 'last_sync_session', 'last_sync_weekly'],
  (stored) => {
    if (stored.claude_lb_team) teamSelect.value = stored.claude_lb_team;
    if (stored.schedule_interval) freqSelect.value = String(stored.schedule_interval);

    scheduleToggle.checked = !!stored.schedule_enabled;
    updateScheduleUI(stored.schedule_enabled, stored.schedule_interval || 60);

    if (stored.last_sync_time) {
      const ago = timeAgo(stored.last_sync_time);
      document.getElementById('lastSync').textContent =
        'Last sync: ' + (stored.last_sync_session || 0) + '% session / ' + (stored.last_sync_weekly || 0) + '% weekly — ' + ago;
      document.getElementById('lastSync').style.display = 'block';
    }
  }
);

// ============================================================
// Team change
// ============================================================
teamSelect.addEventListener('change', () => {
  chrome.storage.local.set({ claude_lb_team: teamSelect.value });
});

// ============================================================
// Schedule toggle & frequency
// ============================================================
scheduleToggle.addEventListener('change', async () => {
  const enabled = scheduleToggle.checked;
  const mins = parseInt(freqSelect.value);
  await chrome.storage.local.set({ schedule_enabled: enabled, schedule_interval: mins });

  if (enabled) {
    await chrome.alarms.create(ALARM_NAME, { periodInMinutes: mins });
  } else {
    await chrome.alarms.clear(ALARM_NAME);
  }
  updateScheduleUI(enabled, mins);
});

freqSelect.addEventListener('change', async () => {
  const mins = parseInt(freqSelect.value);
  await chrome.storage.local.set({ schedule_interval: mins });

  if (scheduleToggle.checked) {
    await chrome.alarms.clear(ALARM_NAME);
    await chrome.alarms.create(ALARM_NAME, { periodInMinutes: mins });
    updateScheduleUI(true, mins);
  }
});

function updateScheduleUI(enabled, mins) {
  if (enabled) {
    scheduleLabel.textContent = 'Active — every ' + formatMins(mins);
    scheduleRow.classList.add('active');
  } else {
    scheduleLabel.textContent = 'Disabled';
    scheduleRow.classList.remove('active');
  }
}

function formatMins(m) {
  if (m < 60) return m + ' min';
  if (m === 60) return '1 hour';
  return (m / 60) + ' hours';
}

// ============================================================
// On popup open — check page
// ============================================================
(async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.url || !tab.url.includes('claude.ai/settings/usage')) {
      setStatus('Open claude.ai/settings/usage to sync now, or enable auto-sync below.', 'info');
      navBtn.style.display = 'block';
      syncBtn.style.display = 'none';
      navBtn.addEventListener('click', () => {
        chrome.tabs.update(tab.id, { url: 'https://claude.ai/settings/usage' });
        window.close();
      });
      return;
    }

    // On the right page — scrape
    setStatus('<span class="spinner"></span> Reading...', 'loading');

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scrapeUsagePage,
    });

    const data = results[0]?.result;
    if (!data || data.error) {
      setStatus(data?.error || 'Could not read usage data. Refresh the page.', 'error');
      return;
    }

    scrapedData = data;
    userEl.textContent = data.name;
    sessEl.textContent = data.sessionPct !== null ? data.sessionPct + '%' : '--';
    weekEl.textContent = data.weeklyPct !== null ? data.weeklyPct + '%' : '--';
    preview.classList.add('visible');

    setStatus('Auto-sync active on this page. Or sync manually:', 'info');
    syncBtn.style.display = 'block';
    syncBtn.addEventListener('click', doSync);

  } catch (err) {
    setStatus('Error: ' + err.message, 'error');
  }
})();

// ============================================================
// Scrape function — injected into the claude.ai tab
// ============================================================
function scrapeUsagePage() {
  let name = null;
  const profileBtn = document.querySelector('button[aria-label*="Settings"]');
  if (profileBtn) {
    const label = profileBtn.getAttribute('aria-label');
    const match = label.match(/^(.+?),\s*Settings/);
    if (match) name = match[1].trim();
  }
  if (!name && profileBtn) {
    const nameSpan = profileBtn.querySelector('span.truncate, span[class*="truncate"]');
    if (nameSpan && nameSpan.textContent.trim().length > 0 && nameSpan.textContent.trim().length < 50) {
      name = nameSpan.textContent.trim();
    }
  }
  if (!name) return { error: 'Could not detect your Claude username.' };

  const re = /(\d{1,3})%\s*used/g;
  const all = [];
  let m;
  while ((m = re.exec(document.body.innerText)) !== null) all.push(parseInt(m[1]));

  let sessionPct = all.length >= 1 ? all[0] : null;
  let weeklyPct = all.length >= 2 ? all[1] : null;
  if (sessionPct === null && weeklyPct === null) {
    return { error: 'No usage data found. Make sure you are on the Usage tab.' };
  }
  return { name, sessionPct, weeklyPct };
}

// ============================================================
// Manual sync
// ============================================================
async function doSync() {
  if (!scrapedData) return;
  syncBtn.disabled = true;
  setStatus('<span class="spinner"></span> Syncing...', 'loading');

  try {
    const payload = {
      name: scrapedData.name,
      team: teamSelect.value,
      source: 'extension',
    };
    if (scrapedData.sessionPct !== null) payload.sessionPct = scrapedData.sessionPct;
    if (scrapedData.weeklyPct !== null) payload.weeklyPct = scrapedData.weeklyPct;

    const res = await fetch(API_BASE + '/api/usage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (data.ok) {
      await chrome.storage.local.set({
        claude_lb_team: teamSelect.value,
        last_sync_name: scrapedData.name,
        last_sync_session: data.sessionPct || 0,
        last_sync_weekly: data.weeklyPct || 0,
        last_sync_time: Date.now(),
      });
      setStatus('&#10003; Synced! Session: ' + (data.sessionPct || 0) + '%, Weekly: ' + (data.weeklyPct || 0) + '%', 'success');
      syncBtn.textContent = 'Synced!';
    } else {
      setStatus('Error: ' + (data.error || 'Unknown'), 'error');
      syncBtn.disabled = false;
    }
  } catch (err) {
    setStatus('Network error: ' + err.message, 'error');
    syncBtn.disabled = false;
  }
}

// ============================================================
// Helpers
// ============================================================
function setStatus(html, type) {
  statusEl.innerHTML = html;
  statusEl.className = 'status ' + type;
}

function timeAgo(ts) {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return mins + 'm ago';
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return hrs + 'h ago';
  return Math.floor(hrs / 24) + 'd ago';
}
